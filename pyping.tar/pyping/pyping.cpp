#include <iostream>
#include <string>
#include <cstdlib>
#include <unistd.h>

using namespace std;

int main(int argc, char **argv)
{
    string host(argv[1]);
    string cmd = string("/bin/sh -c '/usr/bin/python3 ./main.py ") + host + string("'");
    uid_t myid = getuid();
    setuid(0);
    int result = system(cmd.c_str());
    setuid(myid);
    return result;
}