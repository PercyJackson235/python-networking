import socket
import sys
import struct
import array

host = sys.argv[1]


def checksum1(pkt):
    total = 0
    for i in range(0, len(pkt), 2):
        w = (pkt[i] << 8) + pkt[i+1] #<< 8)
        total += w
        total = (total >> 16) + (total & 0xffff)
    return ~total & 0xffff


def checksum(pkt):
    if len(pkt) % 2 == 1:
        pkt += "\0"
    s = sum(array.array("H", pkt))
    s = (s >> 16) + (s & 0xffff)
    s += s >> 16
    s = ~s
    return s & 0xffff


def checksum2(msg):
    s = 0  # Binary Sum

    # loop taking 2 characters at a time
    for i in range(0, len(msg), 2):
        a = ord(msg[i])
        b = ord(msg[i + 1])
        s = s + (a + (b << 8))
    # One's Complement
    s = s + (s >> 16)
    return ~s & 0xffff


try:
    host = socket.gethostbyname(host)
except socket.gaierror:
    print(f"Host {host} is does not exist.")
sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, 1)
data = (8, 0, 0, 1, 1, 5)
check = checksum(data)
data = (8, 0, check, 1, 1, 5)
print(check)
packet = struct.pack('BBHHHI', *data)
b = [int(i, 16) for i in '45 00 00 14 00 01 00 00 40 00 4D F7 0A 0A 0E 19 0A 0A 0A C6'.split()]
ip = struct.pack(f"!{len(b)}B", *b)

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    sock.connect((host, 0))
    sock.send(packet)
    print(sock.recv(1024))
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
